//
//package guess.number;
//
//public class ModoTreino extends Jogador {
//    public ModoTreino(String nome) {
//        super(nome);
//    }
//
//    public int tentativasExtra() {
//        return 3;
//    }
//}

