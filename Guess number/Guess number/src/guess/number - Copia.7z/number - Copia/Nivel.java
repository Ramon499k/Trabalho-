
package guess.number;

public abstract class Nivel {
       public abstract int getTentativas();
} 
