
package guess.number;

public class JogadorComum extends Jogador{
    public JogadorComum(String nome) {
        super(nome);
    }
}

