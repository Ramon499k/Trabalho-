
package guess.number;

public class Facil extends Nivel{
   public int getTentativas() {
        return 3;
    }
} 

