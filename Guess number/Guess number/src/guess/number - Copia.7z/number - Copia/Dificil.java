
package guess.number;


public class Dificil extends Nivel {
    
public int getTentativas() {
        return 2;
    }
}
